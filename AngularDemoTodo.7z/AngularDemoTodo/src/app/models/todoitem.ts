export class TodoItem
{
   public ItemName : string;
   public IsCompleted : boolean;
   
   constructor(){};
}